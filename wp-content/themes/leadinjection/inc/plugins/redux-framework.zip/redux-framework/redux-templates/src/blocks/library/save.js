const save = () => null

export default save
